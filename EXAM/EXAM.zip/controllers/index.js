const home = require('./homeController');
const user = require('./usersController');
const expense = require('./expensesController');

module.exports = {
    home,
    user,
    expense
}