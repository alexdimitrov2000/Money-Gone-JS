const home = require('./home');
const user = require('./user');
const expense = require('./expense');

module.exports = {
    home,
    user,
    expense
}